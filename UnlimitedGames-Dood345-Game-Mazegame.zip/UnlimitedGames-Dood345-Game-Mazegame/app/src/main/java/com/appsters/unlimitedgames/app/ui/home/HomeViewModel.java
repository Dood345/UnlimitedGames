package com.appsters.unlimitedgames.app.ui.home;

import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {
    // TODO: Implement ViewModel
}
