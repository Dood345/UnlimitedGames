package com.appsters.unlimitedgames.app.ui.leaderboard;

import androidx.lifecycle.ViewModel;

public class LeaderboardViewModel extends ViewModel {
    // TODO: Implement ViewModel
}
