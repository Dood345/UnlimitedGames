package com.appsters.unlimitedgames.app.util;

public class Constants {
    // TODO: Add any constant values here
}
