package com.appsters.unlimitedgames.app.util;

import android.graphics.Bitmap;

public class QRCodeHelper {

    // TODO: Implement QR code generation logic
    public static Bitmap generateQRCode(String text) {
        return null;
    }
}
