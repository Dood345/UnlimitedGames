package com.appsters.unlimitedgames.app.util;

public enum RequestStatus {
    PENDING, ACCEPTED, REJECTED
}
