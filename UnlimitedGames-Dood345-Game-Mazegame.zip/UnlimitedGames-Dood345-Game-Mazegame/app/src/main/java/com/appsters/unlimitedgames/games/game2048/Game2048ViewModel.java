package com.appsters.unlimitedgames.games.game2048;

import androidx.lifecycle.ViewModel;

public class Game2048ViewModel extends ViewModel {
    // TODO: Implement ViewModel
}
