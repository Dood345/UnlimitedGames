package com.appsters.unlimitedgames.games.game2048.repository;

public class Cam2048Repository {
}
