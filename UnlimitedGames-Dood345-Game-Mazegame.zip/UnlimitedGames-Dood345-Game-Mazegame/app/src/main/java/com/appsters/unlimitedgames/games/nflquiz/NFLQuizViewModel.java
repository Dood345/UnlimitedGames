package com.appsters.unlimitedgames.games.nflquiz;

import androidx.lifecycle.ViewModel;

public class NFLQuizViewModel extends ViewModel {
    // TODO: Implement ViewModel
}
