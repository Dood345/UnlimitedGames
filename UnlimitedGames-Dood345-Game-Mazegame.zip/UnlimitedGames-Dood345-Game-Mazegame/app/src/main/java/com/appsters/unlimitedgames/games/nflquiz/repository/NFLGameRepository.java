package com.appsters.unlimitedgames.games.nflquiz.repository;

public class NFLGameRepository {
}
