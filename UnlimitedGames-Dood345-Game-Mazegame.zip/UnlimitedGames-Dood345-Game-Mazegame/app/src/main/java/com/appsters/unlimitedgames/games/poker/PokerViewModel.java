package com.appsters.unlimitedgames.games.poker;

import androidx.lifecycle.ViewModel;

public class PokerViewModel extends ViewModel {
    // TODO: Implement ViewModel
}
