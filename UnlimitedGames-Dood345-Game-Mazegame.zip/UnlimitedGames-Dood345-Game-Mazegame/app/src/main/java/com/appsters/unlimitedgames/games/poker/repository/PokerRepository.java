package com.appsters.unlimitedgames.games.poker.repository;

public class PokerRepository {
}
